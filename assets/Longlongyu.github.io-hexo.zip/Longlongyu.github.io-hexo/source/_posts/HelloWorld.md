---
title: Hello-Hexo!
date: 2018-06-20 14:39:37
abstract: 搭建了自己的博客，这应该算是一件非常酷的事！
tags:
- learn
---

# Hello，Hexo!
使用了Github提供的免费个人页和Hexo博客框架搭建的博客。

希望可以利用这个平台更好的学习激励自己，多记录自己学习经历。

![hexo](/assets/hexo.jpg)